USE BluejackBioskop

--1
SELECT
FilmID,
FilmName,
FilmShowTime
FROM Film
WHERE LEN(FilmName) > 15

--2
SELECT
TransactionID,
[Name] = LOWER(CustomerName),
TransactionDate
FROM HeaderTransaction ht
JOIN Customer c ON ht.CustomerID = c.CustomerID
WHERE DATENAME(MONTH, TransactionDate) = 'March'

--3
SELECT 
[Title] = FilmName,
Price = 'IDR' + CAST(FilmPriceTicket AS VARCHAR) + ',-',
[Gross Profit] = 'IDR ' + CAST(SUM(Quantity) * FilmPriceTicket AS VARCHAR) + ',-'
FROM Film f
JOIN DetailTransaction dt ON f.FilmID = dt.FilmID
WHERE FilmName LIKE '% %'
GROUP BY  FilmPriceTicket, FilmName 

--4
SELECT
CustomerName,
ht.TransactionID,
CONVERT(VARCHAR, TransactionDate, 107),
[Total of Film] = CAST(COUNT(FilmID)AS VARCHAR) + 'film(s)',
[Total Quantity] = SUM(Quantity)
FROM Customer c
JOIN HeaderTransaction ht ON c.CustomerID = ht.CustomerID
JOIN DetailTransaction dt ON ht.TransactionID = dt.TransactionID
WHERE YEAR(CustomerDOB)%2 =0
GROUP BY CustomerName,ht.TransactionID,TransactionDate
UNION
SELECT
CustomerName,
ht.TransactionID,
TransactionDate,
[Total of Film] = CAST(COUNT(FilmID)AS VARCHAR) + 'film(s)',
[Total Quantity] = SUM(Quantity)
FROM Customer c
JOIN HeaderTransaction ht ON c.CustomerID = ht.CustomerID
JOIN DetailTransaction dt ON ht.TransactionID = dt.TransactionID
WHERE LEN(CustomerName) > 7
GROUP BY CustomerName,ht.TransactionID,TransactionDate, Quantity
ORDER BY SUM(Quantity) DESC

--5
SELECT
CustomerName,
CustomerAddress,
CustomerEmail,
[Date of Birth] = CONVERT(VARCHAR,CustomerDOB, 106)
FROM Customer c
JOIN HeaderTransaction ht ON C.CustomerID = ht.CustomerID
JOIN DetailTransaction dt ON ht.TransactionID = dt.TransactionID
JOIN Film f ON dt.FilmID = f.FilmID
JOIN FilmGenre fg ON f.FilmGenreID = fg.FilmGenreID
WHERE MONTH(TransactionDate) = 2 AND 
FilmGenreName IN (
	SELECT
	FilmGenreName
	FROM FilmGenre
	WHERE FilmGenreName = 'Action'
)
ORDER BY CustomerDOB DESC

--6
SELECT DISTINCT
c.CustomerID,
CustomerName,
CustomerPhoneNumber,
CustomerEmail
FROM Customer c
JOIN HeaderTransaction ht ON c.CustomerID = ht.CustomerID
JOIN DetailTransaction dt ON ht.TransactionID = dt.TransactionID,
(
	SELECT
	AVG(Quantity) as avg
	FROM DetailTransaction
) x
WHERE dt.Quantity > avg AND (CustomerName LIKE '%a%' OR CustomerName LIKE '%a' OR CustomerName LIKE 'a%')
ORDER BY CustomerName

--7
CREATE VIEW [ContractRoleView]
AS
SELECT 
[StaffID] = 'Staff ' + RIGHT(StaffID,1),
StaffName,
StaffAddress,
StaffRoleName,
StaffRoleSalary
FROM Staff s
JOIN StaffRole sr ON s.StaffRoleID = sr.StaffRoleID
WHERE StaffRoleName != 'Cashier'

--8
CREATE VIEW [TransactionDataOfRomanceFilm]
AS
SELECT TOP 100 PERCENT
ht.TransactionID,
[Day of Transaction] = DATENAME(WEEKDAY,TransactionDate),
TransactionDate,
[Film Title] = FilmName,
[Total Quantity] = SUM(Quantity)
FROM HeaderTransaction ht
JOIN DetailTransaction dt ON ht.TransactionID = dt.TransactionID
JOIN Film f ON dt.FilmID = f.FilmID
JOIN FilmGenre fg ON f.FilmGenreID = fg.FilmGenreID
WHERE FilmGenreName = 'Romance'
GROUP BY ht.TransactionID, TransactionDate, FilmName
ORDER BY TransactionDate ASC -- kalo maksain pake order by di view saya kasih top 100 PERCENT

SELECT * FROM TransactionDataOfRomanceFilm ORDER BY TransactionDate ASC -- diselect baru ada order by nya

--9
ALTER TABLE Customer
ADD CustomerSocialMedia VARCHAR(30)

ALTER TABLE Customer
ADD CONSTRAINT CT_Customer_CheckCustomerSocialMedia CHECK (LEN(CustomerSocialMedia) BETWEEN 5 AND 25)

--10
DELETE Customer
FROM Customer c
JOIN HeaderTransaction ht ON c.CustomerID = ht.CustomerID
JOIN DetailTransaction dt ON ht.TransactionID = dt.TransactionID
WHERE Quantity > 8 AND MONTH(TransactionDate)%2 = 0



SELECT * FROM ContractRoleView
SELECT * FROM Film
SELECT * FROM DetailTransaction
SELECT * FROM Customer
SELECT * FROM Staff
SELECT * FROM FilmGenre
SELECT * FROM StaffRole
